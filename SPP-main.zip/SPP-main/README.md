# Solar Data Prediction Website

This is a website which will give the result of Solar Power Generation. This is based on Artificial Neural network.

# Screenshorts

| Home      |
|------------|
| <img src="https://user-images.githubusercontent.com/82761457/189285313-fa67ce0c-3637-44e4-8abd-eefc2c066724.png"> |

| Scroll      |
|------------|
| <img src="https://user-images.githubusercontent.com/82761457/189285594-db396678-0e96-467a-84a5-507d128c15e6.png"> |
